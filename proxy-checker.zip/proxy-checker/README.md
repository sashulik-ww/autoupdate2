# Proxy checker (СПб)

Каждый час скачивает список прокси, проверяет их и кладёт рабочие в `results/`:

- `results/working_proxies.txt` — рабочие прокси, по одному на строку, быстрые сверху
- `results/working_proxies.json` — то же + задержка, страна/метка, время проверки

## Почему self-hosted runner

Обычные раннеры GitHub находятся в США, а не в России — проверка на них ничего не скажет
о работе прокси из СПб. Поэтому нужен свой runner на машине/VPS в Санкт-Петербурге.

1. Репозиторий → Settings → Actions → Runners → New self-hosted runner, следуй инструкции.
2. При настройке добавь лейбл `spb` (`./config.sh ... --labels spb`).
3. Запусти как сервис: `sudo ./svc.sh install && sudo ./svc.sh start`.
4. Нужен `python3` и `python3-venv` на этой машине.
5. Держи репозиторий **приватным**: в публичном репозитории чужие pull request'ы
   могут исполнять код на твоей машине.

Скрипт сам определяет геолокацию runner'а (ip-api.com) и падает, если это не СПб.

## Настройки (переменные окружения)

| Переменная    | По умолчанию                                         |
|---------------|------------------------------------------------------|
| `SOURCE_URL`  | ссылка на список                                     |
| `TEST_URLS`   | `http://www.gstatic.com/generate_204\|204,https://ya.ru` |
| `CONCURRENCY` | `200`                                                |
| `TIMEOUT`     | `10` (секунд на запрос)                              |
| `REQUIRE_SPB` | `true`                                               |

Локальный запуск: `pip install -r requirements.txt && python checker.py`
